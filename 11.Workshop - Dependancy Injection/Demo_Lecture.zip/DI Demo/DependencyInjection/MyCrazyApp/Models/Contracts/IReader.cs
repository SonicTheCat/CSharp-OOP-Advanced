﻿namespace MyCrazyApp.Models.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
