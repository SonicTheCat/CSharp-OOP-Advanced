﻿namespace MyCrazyApp.Models.Contracts
{
    public interface IWriter
    {
        void Write(string text);
    }
}
