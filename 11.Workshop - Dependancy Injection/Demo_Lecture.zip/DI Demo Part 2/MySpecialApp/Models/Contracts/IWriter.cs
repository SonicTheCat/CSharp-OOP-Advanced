﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MySpecialApp.Models.Contracts
{
    public interface IWriter
    {
        void Write(string content);
    }
}
