﻿using System;

[AttributeUsage(AttributeTargets.Property)]
public class InjectAttribute : Attribute
{

}